package com.mscourse.creditevaluator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreditEvaluatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreditEvaluatorApplication.class, args);
	}

}
